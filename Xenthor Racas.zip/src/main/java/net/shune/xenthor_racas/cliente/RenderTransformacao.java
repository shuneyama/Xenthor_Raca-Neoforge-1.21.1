package net.shune.xenthor_racas.cliente;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.BatModel;
import net.minecraft.client.model.CodModel;
import net.minecraft.client.model.WolfModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

public class RenderTransformacao {

    private static final ResourceLocation TEXTURA_MORCEGO = ResourceLocation.withDefaultNamespace("textures/entity/bat.png");
    private static final ResourceLocation TEXTURA_LOBO = ResourceLocation.withDefaultNamespace("textures/entity/wolf/wolf.png");
    private static final ResourceLocation TEXTURA_BACALHAU = ResourceLocation.withDefaultNamespace("textures/entity/fish/cod.png");

    private static BatModel modeloMorcego;
    private static WolfModel<?> modeloLobo;
    private static CodModel<?> modeloBacalhau;

    private static boolean inicializado = false;

    private static void inicializar() {
        if (inicializado) return;
        inicializado = true;

        Minecraft mc = Minecraft.getInstance();
        if (mc.getEntityModels() == null) return;

        try {
            modeloMorcego = new BatModel(mc.getEntityModels().bakeLayer(ModelLayers.BAT));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            modeloLobo = new WolfModel<>(mc.getEntityModels().bakeLayer(ModelLayers.WOLF));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            modeloBacalhau = new CodModel<>(mc.getEntityModels().bakeLayer(ModelLayers.COD));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean renderizar(Player jogador, float partialTick, PoseStack poseStack,
                                     MultiBufferSource buffer, int packedLight) {
        String forma = TransformacaoCache.obter(jogador.getUUID());
        if (forma.isEmpty()) return false;

        inicializar();

        poseStack.pushPose();

        switch (forma) {
            case "morcego" -> {
                if (modeloMorcego == null) { poseStack.popPose(); return false; }
                poseStack.translate(0.0, 1.2, 0.0);
                poseStack.scale(1.5f, 1.5f, 1.5f);
                poseStack.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180.0f - jogador.getYRot()));
                var vertexConsumer = buffer.getBuffer(RenderType.entityCutout(TEXTURA_MORCEGO));
                modeloMorcego.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY);
            }
            case "lobo" -> {
                if (modeloLobo == null) { poseStack.popPose(); return false; }
                poseStack.translate(0.0, 1.1, 0.0);
                poseStack.scale(1.2f, 1.2f, 1.2f);
                poseStack.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180.0f - jogador.getYRot()));
                var vertexConsumer = buffer.getBuffer(RenderType.entityCutout(TEXTURA_LOBO));
                modeloLobo.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY);
            }
            case "peixe" -> {
                if (modeloBacalhau == null) { poseStack.popPose(); return false; }
                poseStack.translate(0.0, 1.4, 0.0);
                poseStack.scale(1.5f, 1.5f, 1.5f);
                poseStack.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180.0f - jogador.getYRot()));
                var vertexConsumer = buffer.getBuffer(RenderType.entityCutout(TEXTURA_BACALHAU));
                modeloBacalhau.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY);
            }
            default -> { poseStack.popPose(); return false; }
        }

        poseStack.popPose();
        return true;
    }
}