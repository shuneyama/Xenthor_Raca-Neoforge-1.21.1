package net.shune.xenthor_racas.cliente;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class TransformacaoCache {

    private static final Map<UUID, String> FORMAS = new ConcurrentHashMap<>();

    public static void definir(UUID uuid, String forma) {
        if (forma == null || forma.isEmpty()) {
            FORMAS.remove(uuid);
        } else {
            FORMAS.put(uuid, forma);
        }
    }

    public static String obter(UUID uuid) {
        return FORMAS.getOrDefault(uuid, "");
    }

    public static boolean estaTransformado(UUID uuid) {
        String forma = FORMAS.get(uuid);
        return forma != null && !forma.isEmpty();
    }
}