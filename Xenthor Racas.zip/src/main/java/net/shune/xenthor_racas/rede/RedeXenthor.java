package net.shune.xenthor_racas.rede;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.shune.xenthor_racas.FormaNegra;
import net.shune.xenthor_racas.cliente.ManipuladorPacoteCliente;

public class RedeXenthor {

    public static void registrar(IEventBus barramentoMod) {
        barramentoMod.addListener(RedeXenthor::aoRegistrarPayloads);
    }

    private static void aoRegistrarPayloads(RegisterPayloadHandlersEvent evento) {
        PayloadRegistrar registrador = evento.registrar("1.0.0");

        registrador.playToClient(
            PacoteClasseEscolhida.TIPO,
            PacoteClasseEscolhida.CODEC,
            ManipuladorPacoteCliente::aoReceberClasseEscolhida
        );

        registrador.playToClient(
            PacoteFormaNegra.TIPO,
            PacoteFormaNegra.CODEC,
            ManipuladorPacoteCliente::aoReceberFormaNegra
        );

        registrador.playToServer(
            PacoteAtivarFormaNegra.TIPO,
            PacoteAtivarFormaNegra.CODEC,
            (pkt, ctx) -> ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer jogador)
                    FormaNegra.tentar(jogador);
            })
        );
    }

    public static void enviarParaJogador(ServerPlayer jogador, String idClasse, String idElemento) {
        PacketDistributor.sendToPlayer(jogador, new PacoteClasseEscolhida(idClasse, idElemento));
    }

    public static void enviarFormaNegra(ServerPlayer jogador, boolean ativa) {
        PacketDistributor.sendToAllPlayers(new PacoteFormaNegra(jogador.getUUID(), ativa));
    }
}
